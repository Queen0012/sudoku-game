
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

public class SudokuGUI extends JFrame {

    private static final int GRID_SIZE = 9;
    private final JTextField[][] grid;
    private int[][] puzzle;
    private int[][] solution;
    private boolean gameStarted = false;

    public SudokuGUI() {
        setTitle("Sudoku game");
        setSize(550, 550); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        grid = new JTextField[GRID_SIZE][GRID_SIZE];
        JPanel gridPanel = new JPanel(new GridLayout(GRID_SIZE, GRID_SIZE));

        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                grid[i][j] = new JTextField(1);
                grid[i][j].setHorizontalAlignment(JTextField.CENTER);
                grid[i][j].setFont(new Font("Monospaced", Font.BOLD, 24));
                grid[i][j].setEditable(false);
                grid[i][j].setBorder(BorderFactory.createLineBorder(Color.BLACK)); 

                // 3x3 blocks
                if ((i + 1) % 3 == 0 && j < GRID_SIZE - 1) {
                    grid[i][j].setBorder(BorderFactory.createMatteBorder(1, 1, 3, 1, Color.BLACK));
                } else if ((j + 1) % 3 == 0 && i < GRID_SIZE - 1) {
                    grid[i][j].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 3, Color.BLACK));
                } else if ((i + 1) % 3 == 0 && (j + 1) % 3 == 0) {
                    grid[i][j].setBorder(BorderFactory.createMatteBorder(1, 1, 3, 3, Color.BLACK));
                }
                gridPanel.add(grid[i][j]);
            }
        }
        add(gridPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton newGameButton = new JButton("New Game");
        JButton checkButton = new JButton("Check");
        JButton solveButton = new JButton("Solve");
        buttonPanel.add(newGameButton);
        buttonPanel.add(checkButton);
        buttonPanel.add(solveButton);
        add(buttonPanel, BorderLayout.SOUTH);


        newGameButton.addActionListener(e -> newGame());
        checkButton.addActionListener(e -> checkSolution());
        solveButton.addActionListener(e -> solveAndDisplay());

        setVisible(true);
    }

    private void newGame() {
        gameStarted = true;
        puzzle = generateSudoku(35); 
        solution = solveSudoku(copyBoard(puzzle)); 
        updateGrid();
    }

    private void checkSolution() {
        if (!gameStarted) {
            showErrorDialog("Start a new game first!");
            return;
        }

        boolean correct = true;
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                String text = grid[i][j].getText();
                if (!text.isEmpty()) {
                    try {
                        int userValue = Integer.parseInt(text);
                        if (userValue != solution[i][j]) {
                            correct = false;
                            break;
                        }
                    } catch (NumberFormatException e) {
                        showErrorDialog("Invalid input: Enter numbers only.");
                        correct = false;
                        break;
                    }
                }
            }
            if (!correct) break;
        }

        if (correct) {
            boolean completelySolved = true;
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    if (grid[i][j].getText().isEmpty()) {
                        completelySolved = false;
                        break;
                    }
                }
                if (!completelySolved) break;
            }
            if (completelySolved) {
                JOptionPane.showMessageDialog(this, "Congratulations! You solved it!");
                gameStarted = false;
            } else {
                JOptionPane.showMessageDialog(this, "Correct so far. Keep going!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect. Try again!");
        }
    }

    private void solveAndDisplay() {
        if (!gameStarted) {
            showErrorDialog("Start a new game first!");
            return;
        }
        int[][] solvedPuzzle = solveSudoku(copyBoard(puzzle));
        if (solvedPuzzle == null) {
            showErrorDialog("Error solving the puzzle (this shouldn't happen with a valid puzzle).");
            return;
        }
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                grid[i][j].setText(String.valueOf(solvedPuzzle[i][j]));
                grid[i][j].setEditable(false);
            }
        }
        gameStarted = false;
    }


    private int[][] generateSudoku(int numClues) {
        int[][] board = new int[GRID_SIZE][GRID_SIZE];
        Random random = new Random();

        if (!fillBoard(board, random)) {
            showErrorDialog("Error generating Sudoku!");
            return null;
        }
        for (int i = 0; i < GRID_SIZE * GRID_SIZE - numClues; i++) {
            int row, col;
            do {
                row = random.nextInt(GRID_SIZE);
                col = random.nextInt(GRID_SIZE);
            } while (board[row][col] == 0);
            board[row][col] = 0;
        }
        return board;
    }

    private boolean fillBoard(int[][] board, Random random) {
        ArrayList<Integer> numbers = new ArrayList<>(java.util.List.of(1, 2, 3, 4, 5, 6, 7, 8, 9));
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                if (board[i][j] == 0) {
                    java.util.Collections.shuffle(numbers);
                    for (int num : numbers) {
                        if (isValid(board, i, j, num)) {
                            board[i][j] = num;
                            if (fillBoard(board, random)) return true;
                            board[i][j] = 0; 
                        }
                    }
                    return false; 
                }
            }
        }
        return true; 
    }


    private int[][] solveSudoku(int[][] board) {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                if (board[row][col] == 0) {
                    for (int num = 1; num <= GRID_SIZE; num++) {
                        if (isValid(board, row, col, num)) {
                            board[row][col] = num;
                            if (solveSudoku(board) != null) return board;
                            board[row][col] = 0; 
                        }
                    }
                    return null; 
                }
            }
        }
        return board; 
    }

    private boolean isValid(int[][] board, int row, int col, int num) {
        for (int i = 0; i < GRID_SIZE; i++) {
            if (board[row][i] == num || board[i][col] == num) return false;
        }
        int boxRowStart = (row / 3) * 3;
        int boxColStart = (col / 3) * 3;
        for (int i = boxRowStart; i < boxRowStart + 3; i++) {
            for (int j = boxColStart; j < boxColStart + 3; j++) {
                if (board[i][j] == num) return false;
            }
        }
        return true;
    }

    private void updateGrid() {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                if (puzzle[i][j] != 0) {
                    grid[i][j].setText(String.valueOf(puzzle[i][j]));
                    grid[i][j].setEditable(false);
                } else {
                    grid[i][j].setText("");
                    grid[i][j].setEditable(true);
                }
            }
        }
    }

    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private int[][] copyBoard(int[][] board) {
        int[][] copy = new int[GRID_SIZE][GRID_SIZE];
        for (int i = 0; i < GRID_SIZE; i++) {
            System.arraycopy(board[i], 0, copy[i], 0, GRID_SIZE);
        }
        return copy;
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SudokuGUI());
    }
}
